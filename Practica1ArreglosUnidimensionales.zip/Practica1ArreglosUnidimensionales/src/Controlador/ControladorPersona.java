/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Persona;

/**
 *
 * @author Santy
 */
public class ControladorPersona {
    Object[] personas = new Object[0];
    
    public void insertar(String nombre, int edad, String genero){
        int tamanio = personas.length;
        Object[] aux = new Object[tamanio + 1];
        System.arraycopy(personas, 0, aux, 0, tamanio);
        personas = null;
        this.personas = new Object[aux.length];
        System.arraycopy(aux, 0, personas, 0, aux.length);
        Persona persona = new Persona(nombre, edad, genero);
        personas[tamanio] = persona;
    }
    
    public void imprir(){
        for (int i = 0; i < personas.length; i++) {
            System.out.println(personas[i].toString());
        }
    }

    public Object[] getPersonas() {
        return personas;
    }

    public void setPersonas(Object[] personas) {
        this.personas = personas;
    }
}
