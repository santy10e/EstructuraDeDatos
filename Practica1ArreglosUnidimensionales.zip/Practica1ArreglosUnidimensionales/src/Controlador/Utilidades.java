/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Santy
 */
public class Utilidades {
    SimpleDateFormat Formato = new SimpleDateFormat("dd/MM/yyyy");

    public String getFecha(JDateChooser jd) {
        if (jd.getDate() != null) {
            return Formato.format(jd.getDate());
        } else {
            return null;
        }
    }
    
    public int calcularEdad(JDateChooser jd){
        String aux = getFecha(jd);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate fechaNac = LocalDate.parse(aux, fmt);
        LocalDate ahora = LocalDate.now();

        Period periodo = Period.between(fechaNac, ahora);
        return periodo.getYears();
    }
    
    public String edad(int edad ){
        if (edad < 14) {
            return "niño -- alimentación: Consuma comidas ligeras y en forma frecuente.";
        }else if (edad >= 14 && edad <= 20) {
            return "Joven -- rica en contenidos calóricos, en azúcares simples o de absorción rápida, en grasas saturadas y en sodio";
        }else if (edad > 20 && edad <= 60) {
            return "Adulto -- Resalta la importancia de las frutas, las verduras, los cereales integrales";
        }else {
            return "Anciano -- Comer alimentos que le entregan muchos nutrientes sin demasiadas calorías extra, como: Frutas y vegetales";
        }
    }

}
