/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Tabla;

import Controlador.Utilidades;
import Modelo.Persona;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Santy
 */
public class Tabla extends AbstractTableModel{
    private Object[] listado;
    Utilidades util = new Utilidades();

    public Object[] getListado() {
        return listado;
    }

    public void setListado(Object[] listado) {
        this.listado = listado;
    }
    

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public int getRowCount() {
        return listado.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
            Persona p = (Persona) listado[rowIndex];
            switch(columnIndex){
                case 0: return p.getNombre();
                case 1: return p.getEdad();
                case 2: return p.getGenero();
                case 3: return util.edad(p.getEdad());
                default: return null;
                
            }
    }
    

    @Override
    public String getColumnName(int column) {
        switch(column){
            case 0: return "Nombre";
            case 1: return "Edad";
            case 2: return "Genero";
            case 3: return "----";
            default: return null;
        }
    }
}

