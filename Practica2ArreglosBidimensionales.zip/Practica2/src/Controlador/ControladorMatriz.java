package Controlador;

import Modelo.ModeloMatriz;
import javax.swing.table.DefaultTableModel;
// @author "Santiago Tene"

public class ControladorMatriz {

    ModeloMatriz[][] tamaño;
    ModeloMatriz tamañoMatriz;

    public ModeloMatriz[][] getTamaño() {
        return tamaño;
    }

    public void setTamaño(ModeloMatriz[][] tamaño) {
        this.tamaño = tamaño;
    }

    public ModeloMatriz getTamañoMatriz() {
        return tamañoMatriz;
    }

    public void setTamañoMatriz(ModeloMatriz tamañoMatriz) {
        this.tamañoMatriz = tamañoMatriz;
    }
    
    public void lecturaMatriz(){
        for (int i = 0; i < tamaño.length; i++) {
            for (int j = 0; j < tamaño.length; j++) {
                
            }
        }
    }



}
