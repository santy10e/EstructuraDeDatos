package Practica2;

// @author "Santiago Tene"
import Controlador.ControladorTresRaya;
import Modelo.ModeloTresRaya;
import Vista.Interfaz;

public class Practica2 {
    public static void main(String[] args) {
       
        
 ModeloTresRaya modelo = new ModeloTresRaya();
        Interfaz vista = new Interfaz();
        ControladorTresRaya controlador = new ControladorTresRaya(vista, modelo);
        controlador.iniciarJuego();
        vista.setVisible(true);
    }

}
