/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import javax.swing.table.DefaultTableModel;
import Controlador.ControladorMatriz;
import javax.swing.JOptionPane;

/**
 *
 * @author "Santiago Tene"
 */
public class Frm_Matriz extends javax.swing.JDialog {

    DefaultTableModel mitabla = new DefaultTableModel();

    ControladorMatriz ctrlMatriz;

    public Frm_Matriz(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    public void tamañoMatriz() {
        tblMatriz.setModel(mitabla);
        mitabla.setColumnCount(Integer.parseInt(txtN.getText()));
        mitabla.setRowCount(Integer.parseInt(txtM.getText()));
        int filas = Integer.parseInt(txtM.getText());
        int columnas = Integer.parseInt(txtN.getText());
        JOptionPane.showMessageDialog(null, "se ha generado una matriz de " + filas + " Filas y " + columnas + " Columnas");
        JOptionPane.showMessageDialog(null, "Llena la tabla haciendo doble clic en la casilla");

    }

    public void sumarFila() {
        int indice = tblMatriz.getSelectedRow();
        int resultado = 0;
        int suma = 0;
        int columnas = Integer.parseInt(txtN.getText());
        if (indice >= 0) {
            JOptionPane.showMessageDialog(null, "Indice de fila seleccionado: " + indice);
            for (int i = 0; i < columnas; i++) {
                resultado = Integer.parseInt(tblMatriz.getValueAt(indice, i).toString());
                suma += resultado;
//                System.out.println("suma" + suma);
//                System.out.println("indice" + indice);
//                System.out.println("resultado" + resultado);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Debe Seleccionar Una Fila de La Tabla");
        }
        System.out.println("Valor" + suma);
        txtPrueba1.setText(String.valueOf(suma));
    }

    public void sumarColumna() {
        int columna = Integer.parseInt(txtSelColumna.getText());
        int filas = Integer.parseInt(txtM.getText());
        int resultado = 0;
        int suma = 0;
        if (columna >= 0) {
            JOptionPane.showMessageDialog(null, "Indice de Columa seleccionado: " + columna);
            for (int i = 0; i < filas; i++) {
                resultado = Integer.parseInt(tblMatriz.getValueAt(i, columna-1).toString());
                suma += resultado;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Debe Seleccionar Una Columna de La Tabla");
        }
        txtSumaColumna2.setText(String.valueOf(suma));
    }

    public void sumarDiagonal() {
        int filas = Integer.parseInt(txtM.getText());
        int columnas = Integer.parseInt(txtN.getText());
        int matriz[][] = new int[filas][columnas];
        int suma = 0;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int indice = Integer.parseInt(tblMatriz.getValueAt(i, j).toString());
                   System.out.println("indice" + indice);
                if (i == j) {
                    suma = suma + indice;
                    System.out.println("suma" + suma);
                }
                if(filas!=columnas){
                    JOptionPane.showMessageDialog(null, "Debe ser una matriz cuadrada");
                }else{
                    txtDiagonal.setText(""+suma);
                }
                matriz[i][j] = indice;
            }
        }
        
    }
    
    public void inversa() {
        int filas = Integer.parseInt(txtM.getText());
        int columnas = Integer.parseInt(txtN.getText());
        int matrizTrans[][] = new int[filas][columnas];
        int matrizTransp=0;
        int suma=0;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizTransp = Integer.parseInt(tblMatriz.getValueAt(j, i).toString());
                
            }   
        }
    }
    
    public void MediaValores() {
        int filas = Integer.parseInt(txtM.getText());
        int columnas = Integer.parseInt(txtN.getText());
        int total = filas + columnas;
        int suma = 0;
        int resultado=0;
        int matrizTrans[][] = new int[filas][columnas];
        int matrizTransp=0;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizTransp = Integer.parseInt(tblMatriz.getValueAt(j, i).toString());
                lblInversa.setText("Hola"+matrizTransp);
            }
        }
        resultado = suma/total;
        System.out.println("Media" +resultado );
        txtMediaVal.setText(""+resultado);
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnGenerar = new javax.swing.JButton();
        txtM = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblMatriz = new javax.swing.JTable();
        txtN = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        tblSelColumna = new javax.swing.JButton();
        txtPrueba1 = new javax.swing.JTextField();
        btnInversa = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnSelecFIla = new javax.swing.JButton();
        txtSelColumna = new javax.swing.JTextField();
        txtSumaColumna2 = new javax.swing.JTextField();
        btnDiagonal1 = new javax.swing.JButton();
        txtDiagonal = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        txtMediaVal = new javax.swing.JTextField();
        lblInversa = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("Filas");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(60, 30, 100, 14);

        btnGenerar.setText("Generar");
        btnGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGenerar);
        btnGenerar.setBounds(450, 50, 110, 23);
        getContentPane().add(txtM);
        txtM.setBounds(30, 50, 150, 30);

        tblMatriz.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tblMatriz.setEditingColumn(1);
        tblMatriz.setEditingRow(1);
        jScrollPane2.setViewportView(tblMatriz);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(70, 100, 430, 270);
        getContentPane().add(txtN);
        txtN.setBounds(260, 50, 150, 30);

        jLabel2.setText("Columnas");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(300, 30, 100, 14);

        tblSelColumna.setText("Seleccionar Columna");
        tblSelColumna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tblSelColumnaActionPerformed(evt);
            }
        });
        getContentPane().add(tblSelColumna);
        tblSelColumna.setBounds(300, 420, 130, 23);
        getContentPane().add(txtPrueba1);
        txtPrueba1.setBounds(440, 380, 60, 30);

        btnInversa.setText("Inversa");
        btnInversa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInversaActionPerformed(evt);
            }
        });
        getContentPane().add(btnInversa);
        btnInversa.setBounds(220, 680, 120, 23);

        jLabel3.setText("Suma diagonal ");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(80, 460, 140, 20);

        jLabel4.setText("Suma de una fila");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(80, 380, 140, 20);

        jLabel5.setText("Seleccionar Columna");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(80, 420, 140, 20);

        btnSelecFIla.setText("Seleccionar Fila");
        btnSelecFIla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelecFIlaActionPerformed(evt);
            }
        });
        getContentPane().add(btnSelecFIla);
        btnSelecFIla.setBounds(230, 380, 120, 23);

        txtSelColumna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSelColumnaActionPerformed(evt);
            }
        });
        getContentPane().add(txtSelColumna);
        txtSelColumna.setBounds(210, 420, 60, 30);
        getContentPane().add(txtSumaColumna2);
        txtSumaColumna2.setBounds(440, 420, 60, 30);

        btnDiagonal1.setText("Sumar");
        btnDiagonal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDiagonal1ActionPerformed(evt);
            }
        });
        getContentPane().add(btnDiagonal1);
        btnDiagonal1.setBounds(230, 460, 120, 23);
        getContentPane().add(txtDiagonal);
        txtDiagonal.setBounds(440, 460, 60, 30);

        jButton1.setText("Media Valores");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 500, 110, 23);
        getContentPane().add(txtMediaVal);
        txtMediaVal.setBounds(440, 500, 60, 30);
        getContentPane().add(lblInversa);
        lblInversa.setBounds(170, 550, 250, 110);

        setBounds(0, 0, 706, 810);
    }// </editor-fold>//GEN-END:initComponents

    private void btnGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarActionPerformed
        // TODO add your handling code here:
        int n = Integer.parseInt(txtN.getText());
        int m = Integer.parseInt(txtM.getText());
        tamañoMatriz();

    }//GEN-LAST:event_btnGenerarActionPerformed

    private void tblSelColumnaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tblSelColumnaActionPerformed
        // TODO add your handling code here:
        sumarColumna();
    }//GEN-LAST:event_tblSelColumnaActionPerformed

    private void btnInversaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInversaActionPerformed
        // TODO add your handling code here:
        inversa();
        
    }//GEN-LAST:event_btnInversaActionPerformed

    private void btnSelecFIlaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelecFIlaActionPerformed
        // TODO add your handling code here:
        sumarFila();
    }//GEN-LAST:event_btnSelecFIlaActionPerformed

    private void txtSelColumnaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSelColumnaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSelColumnaActionPerformed

    private void btnDiagonal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDiagonal1ActionPerformed
        // TODO add your handling code here:
        sumarDiagonal();
    }//GEN-LAST:event_btnDiagonal1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        MediaValores();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frm_Matriz.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frm_Matriz.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frm_Matriz.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frm_Matriz.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Frm_Matriz dialog = new Frm_Matriz(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDiagonal1;
    private javax.swing.JButton btnGenerar;
    private javax.swing.JButton btnInversa;
    private javax.swing.JButton btnSelecFIla;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblInversa;
    private javax.swing.JTable tblMatriz;
    private javax.swing.JButton tblSelColumna;
    private javax.swing.JTextField txtDiagonal;
    private javax.swing.JTextField txtM;
    private javax.swing.JTextField txtMediaVal;
    private javax.swing.JTextField txtN;
    private javax.swing.JTextField txtPrueba1;
    private javax.swing.JTextField txtSelColumna;
    private javax.swing.JTextField txtSumaColumna2;
    // End of variables declaration//GEN-END:variables
}
